<h1><?= $h1; ?></h1>
<div id="content">
	<!--<?= $text; ?>-->
</div>