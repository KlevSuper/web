<p><?= $page['content'] ?></p>
<a href="/page/">← Вернуться к списку страниц</a>