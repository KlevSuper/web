<?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'y91550gt_mvc');
	define('DB_PASS', 'qwe123_');
	define('DB_NAME', 'y91550gt_mvc');
