<?php
	define('DB_HOST', 'localhost');
	define('DB_USER', '<login>_mvc');
	define('DB_PASS', '******');
	define('DB_NAME', '<login>_mvc');
