<?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'f1091114_mvc');
	define('DB_PASS', 'ncu6XfJx');
	define('DB_NAME', 'f1091114_mvc');
