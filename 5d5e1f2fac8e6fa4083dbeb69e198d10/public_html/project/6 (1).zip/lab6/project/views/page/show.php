<p><?= $page['content'] ?></p>
<a href="/lab6/page/">← Вернуться к списку страниц</a>