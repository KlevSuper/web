<h1>Тестовое действие <?= $actionNumber ?></h1>
<p><?= $message ?></p>
